class Form {
    constructor() {
        this.question = createElement('h3')
    }

    getScore(){
        database.ref('score').on("value", (data)=>{
            score = data.val();
        })
    }
    
    updateScore(newScore){
        database.ref('/').update({
            score:newScore
        })
    }

    display() {
        var title = createElement('h1')
        title.html('Welcome To My Game !!')
        title.position(150, 50)
        var content = createElement('h3')
        content.html('This is a life happiness simulator you are given decisions and based on that your happiness.<br> The decisons will either increase or decrease,you need to try and live the happiest life ')
        content.position(90, 150)

        var Button = createButton('Enter')
        Button.position(950, 480)

        Button.mousePressed(() => {
            title.hide()
            content.hide()
            Button.hide()

            this.question.position(80, 80)
            this.question.html('Q. What is your favourite toy? ')

            choice1 = createElement('h4')
            choice2 = createElement('h4')
            choice3 = createElement('h4')
            choice4 = createElement('h4')

            choice1.html('A. Barbie')
            choice2.html('B. Car')
            choice3.html('C. Superhero')
            choice4.html('D. Phone')

            choice1.position(200, 200)
            choice2.position(200, 230)
            choice3.position(200, 260)
            choice4.position(200, 290)

            var answer = createInput("Enter the right choice")
            var submit = createButton("Submit")

            answer.position(500, 250)
            submit.position(700, 250)

            submit.mousePressed(() => {
                game.updateState(1)
            })
           
            
            


        });
    }


    end(){
        var happiness = createElement('h3')
        happiness.position(400, 400)
        happiness.html('Happiness: ' + score + ' %')
    }
   
}

