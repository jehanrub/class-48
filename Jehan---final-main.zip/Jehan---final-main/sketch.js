var gameState=0 
var form,game
var score = 0;
var choice1, choice2, choice3, choice4
var database
var happiness
var x


function setup(){
    createCanvas(1000,500)
    database=firebase.database()
    game=new Game()
    game.getState();
    game.start();
}



function draw (){
    background('lightgreen')

    if(gameState === 1){
        game.play();
    }
}














