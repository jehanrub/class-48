class Game {
    constructor() {


    }
    getState() {
        database.ref('gameState').on("value", (data) => {
            gameState = data.val();
        })
    }
    updateState(state) {
        database.ref('/').update({
            gameState: state
        })
    }
    start() {
        if (gameState === 0) {
            form = new Form()
            form.display()
            form.getScore()
        }
    }


    play() {
            form.updateScore(70)
            form.end();
     
    }
}